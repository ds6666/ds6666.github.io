from django.contrib import admin

# Register your models here.
from firstapp.models import Article, Comment, Ticket, UserProfile

admin.site.register([Article, Comment, Ticket, UserProfile])