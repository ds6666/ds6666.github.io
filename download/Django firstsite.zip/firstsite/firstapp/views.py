from django.shortcuts import render, redirect
from django.http import HttpResponse
from firstapp.models import Article, Comment, Ticket
from firstapp.forms import CommentForm
from django.contrib.auth import authenticate, login
from django.core.paginator import Paginator
from django.core.paginator import EmptyPage
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.core.paginator import PageNotAnInteger
from django.core.exceptions import ObjectDoesNotExist


# Create your views here.

def index(request):
    a_tag = request.GET.get('tag')
    if a_tag:
        article_list = Article.objects.filter(tag=a_tag)
    else:
        article_list = Article.objects.all()
    page_robot = Paginator(article_list, 6)
    page_num = request.GET.get('page')
    try:
        article_list = page_robot.page(page_num)
    except EmptyPage:
        article_list = page_robot.page(page_robot.num_pages)
    except PageNotAnInteger:
        article_list = page_robot.page(1)

    context = {}
    context["article_list"] = article_list

    return render(request, 'index.html', context)


def detail(request, id, error_form=None):
    article = Article.objects.get(id=id)

    if request.method == "GET":
        form = CommentForm
    best_comment = Comment.objects.filter(best_comment=True, belong_to=article)
    context = {}
    if best_comment:
        context["best_comment"] = best_comment[0]
    context["article"] = article
    if error_form is not None:
        context['form'] = error_form
    else:
        context['form'] = form
    if hasattr(request.user,'profile'):
        voter_id = request.user.profile.id
    like_counts = Ticket.objects.filter(choice='like', video_id=id).count()
    try:
        user_ticket_for_this_video = Ticket.objects.get(voter_id=voter_id, video_id=id)
        context['user_ticket'] = user_ticket_for_this_video
    except:
        pass
    context['like_counts'] = like_counts
    return render(request, 'detail.html', context)


def comment(request, id):
    form = CommentForm(request.POST)
    if form.is_valid():
        name = form.cleaned_data["name"]
        comment = form.cleaned_data["comment"]
        article = Article.objects.get(id=id)
        c = Comment(name=name, comment=comment, belong_to=article)
        c.save()
        return redirect(to="detail", id=id)
    else:
        return redirect(to="detail", id=id, error_form = form)

    return redirect(to="detail", id=id)

def detail_vote(request, id):
    if hasattr(request.user,'profile'):
        voter_id = request.user.profile.id
        try:
            user_ticket_for_this_video = Ticket.objects.get(voter_id=voter_id, video_id=id)
            user_ticket_for_this_video.choice = request.POST['vote']
            user_ticket_for_this_video.save()
        except ObjectDoesNotExist:
            new_ticket = Ticket(voter_id=voter_id, video_id=id, choice=request.POST['vote'])
            new_ticket.save()
        return redirect(to='detail', id=id)
    else:
        return HttpResponse('<h1>请先登录，在进行投票操作</h1>\n<a href="../login" target="_blank">点击登录</a>')

def index_login(request):
    context = {}
    if request.method == 'GET':
        form = AuthenticationForm
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect(to='index')
    context['form'] = form
    return render(request, 'register_login.html', context)

def index_register(request):
    context = {}
    if request.method == 'GET':
        form = UserCreationForm
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect(to='login')
    context['form'] = form
    return render(request, 'register_login.html', context)