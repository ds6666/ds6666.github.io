from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class UserProfile(models.Model):
    belong_to = models.OneToOneField(to=User, related_name='profile', on_delete=models.CASCADE)
    profile_image = models.FileField(upload_to='upload/profile_image')
    def __str__(self):
        return self.belong_to.username

class Article(models.Model):
    title = models.CharField(max_length=500)
    url_image = models.URLField(null=True, blank=True, default='')
    cover = models.FileField(upload_to='upload/cover_image', default='upload/cover_image/boss-fight-stock-images-photos-free-stuff-on-table.jpg',null=True)
    content = models.TextField(null=True, blank=True)
    views = models.IntegerField(default=0)
    TAG_CHOICES=(
        ('js','JS'),
        ('web','WEB'),
        ('others','OTHERS')
    )
    tag = models.CharField(max_length=8, null=True, blank=True, choices=TAG_CHOICES, default='')
    likes = models.IntegerField(default=0)
    owner = models.ForeignKey(to=UserProfile,related_name='ow_article',default=2,on_delete=models.CASCADE)
    createtime = models.DateTimeField(auto_now=True)
    editors_choice = models.BooleanField(default=False)

    def __str__(self):
        return self.title


class Comment(models.Model):
    name = models.CharField(max_length=500)
    avatar = models.CharField(max_length=250, default="upload/images/default.png")
    comment = models.TextField(null=True, blank=True)
    createtime = models.DateField(auto_now=True)

    belong_to = models.ForeignKey(to=Article, related_name="under_comments", null=True, blank=True,
                                  on_delete=models.CASCADE)
    best_comment = models.BooleanField(default=False)
    def __str__(self):
        return self.name



class Ticket(models.Model):
    voter = models.ForeignKey(to=UserProfile, related_name='voted_tickets', on_delete=models.CASCADE)
    video = models.ForeignKey(to=Article, related_name='tickets', on_delete=models.CASCADE)
    VOTE_CHOICES = (
        ('like', 'like'),
        ('dislike', 'dislike'),
        ('normal', 'normal'),
        )
    choice = models.CharField(choices=VOTE_CHOICES, max_length=10)

    def __str__(self):
        return str(self.id)