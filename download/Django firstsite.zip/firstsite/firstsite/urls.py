"""firstsite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.conf import settings
from django.contrib import admin
from firstapp.views import index, detail, comment, index_login, index_register, detail_vote
from firstapp.api import article,article_card
from firstapp.mobile_views import m_index
from rest_framework.authtoken import views
from django.contrib.auth.views import LogoutView
from django.conf.urls.static import static

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^index/', index, name="index"),
    url(r'^detail/(?P<id>\d+)/$', detail, name="detail"),
    url(r'^comment/(?P<id>\d+)/$', comment, name="comment"),
    url(r'^detail/vote/(?P<id>\d+)$', detail_vote, name='vote'),
    url(r'^login/$', index_login, name='login'),
    url(r'^register/$', index_register, name='register'),
    url(r'^logout/$', LogoutView.as_view(next_page= '/register'), name='logout'),
    url(r'^api/Article$', article, name='a_api'),
    url(r'^api/Article/(?P<id>\d+)$', article_card, name='aid_api'),
    url(r'^api/token-auth$', views.obtain_auth_token),
    url(r'^m/index$', m_index, name='aid_api'),
]

urlpatterns += static(settings.UPLOAD_URL, document_root=settings.UPLOAD_ROOT)
