from django.contrib import admin
from zqgl.models import *
# Register your models here.

admin.site.register([Userl,Zqgl,Grzq,Mr,Jezh,Cunkuan])
