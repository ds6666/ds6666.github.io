from django.apps import AppConfig


class ZqglConfig(AppConfig):
    name = 'zqgl'
