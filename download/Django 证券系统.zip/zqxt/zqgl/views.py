from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.views.decorators.csrf import csrf_exempt
import cx_Oracle
import time
from zqgl.models import *
# Create your views here.
usr=[]
db = cx_Oracle.connect('nanqu', 'tiger', 'localhost/south')
def inser(sql,pr,db):
    cr=db.cursor()
    cr.execute(sql,pr)
    cr.close()
    db.commit()

def select(sql,pr,db):
    cr = db.cursor()
    cr.execute(sql,pr)
    rs = cr.fetchall()
    cr.close()
    return rs


def login(request):
    return render(request,'login.html')

def register(request):
    return render(request,'zhuce.html')

@csrf_exempt
def login_check(request):
    global usr
    user_list = Userl.objects.all()
    if request.method=='POST':
        u=request.POST.get('username','')
        p=request.POST.get('password','')
        if u=='zqdba' and p=='tiger':
            return HttpResponseRedirect('/zq_admin/')
        else:
            for user in user_list:
                if user.username==u and user.pass_field==p:
                    usr.append(user)
                    return HttpResponseRedirect('/zq_user/')
            else:
                return HttpResponse('<h1>用户名或密码错误</h1>')

@csrf_exempt
def register_check(request):
    if request.method=='POST':
        u=request.POST.get('username','')
        p=request.POST.get('password','')
        r=request.POST.get('repassword','')
        if p!=r:
            return HttpResponse('<h1>两次输入密码不一致</h1>')
        elif u=='' or p=='':
            return HttpResponse('<h1>用户名或密码为空</h1>')
        elif u!='' and p==r!='':
            us=Userl(username=u,pass_field=p,u_name=u)
            us.save()
            return HttpResponse('<h1>注册成功</h1>\n<a href="../index/login" target="_blank">点击登录</a>')



def zq_admin(request):
    return render(request,'zq_admin.html')

def zq_user(request):
    context={}
    context['user']=usr[-1]
    return render(request,'zq_user.html',context)

def zqtj(request):
    return render(request,'zqtj.html')


@csrf_exempt
def adzq(request):
    if request.method=='POST':
        dm=request.POST.get('dm','')
        zqname=request.POST.get('zqname','')
        newprice=request.POST.get('newprice','')
        mrj = request.POST.get('mrj', '')
        mcj = request.POST.get('mcj', '')
        kc = request.POST.get('kc', '')
        cjl = request.POST.get('cjl', '')
        zq=Zqgl(dm=dm,zqname=zqname,newprice=newprice,mrj=mrj,mcj=mcj,kc=kc,cjl=cjl)
        zq.save()
        return HttpResponse('<h1>添加成功</h1>\n<a href="../zqtj" target="_blank">继续添加</a>')


def zqhq(request):
    context={}
    zq_list=Zqgl.objects.all()
    context['zq_list']=zq_list
    return render(request,'zqhq.html',context)

def ktzj(request):
    return render(request,'ktzj.html')

@csrf_exempt
def adzj(request):
    u_list=Userl.objects.all()
    if request.method=='POST':
        username=request.POST.get('username','')
        yhkh=request.POST.get('yhkh','')
        realname=request.POST.get('realname','')
        if username!='':
            for u in u_list:
                if username==u.username:
                    sql='insert into jezh values(:username,:yhkh,:realname,:yue)'
                    zj={
                        'username':username,
                        'yhkh':yhkh,
                        'realname':realname,
                        'yue':10.00
                    }
                    inser(sql,zj,db)
                    return HttpResponse('<h1>开通成功</h1>\n<a href="../ktzj" target="_blank">继续开通</a>')
            else:
                return HttpResponse('<h1>用户不存在</h1>')
        else:
            return HttpResponse('<h1>请输入用户名</h1>')

def ck(request):
    return render(request,'ck.html')

@csrf_exempt
def adck(request):
    if request.method=='POST':
        username=request.POST.get('username','')
        ckmoney=request.POST.get('ckmoney','')
        realname=request.POST.get('realname','')
        ckdat=time.asctime(time.localtime(time.time()))
        sql='select yue from jezh where username=:username'
        pr={
            'username':username
        }
        yue=select(sql,pr,db)
        if yue:
            ck=Cunkuan(username_ck=username,realname=realname,ckmoney=ckmoney,ckdat=ckdat)
            ck.save()
            sql1='call upd(:username,:cmoney)'
            pr1={
                'username':username,
                'cmoney':yue[0][0]+float(ckmoney)
            }
            inser(sql1,pr1,db)
            return HttpResponse('<h1>存款成功</h1>\n<a href="../ck" target="_blank">继续存款</a>')
        else:
            return HttpResponse('<h1>用户不存在或未开通资金账户</h1>')

def fh(request):
    return render(request,'fh.html')

def szfh(request):
    return render(request,'szfh.html')

def xjfh(request):
    return render(request,'xjfh.html')

@csrf_exempt
def fhsz(request):
    if request.method=='POST':
        username=request.POST.get('username','')
        dm=request.POST.get('dm','')
        sg=request.POST.get('sg','')
        zg=request.POST.get('zg','')
        sql='call sz(:username,:dm,:sz)'
        pr={
            'username': username,
            'sz': sg+zg,
            'dm': dm
        }
        inser(sql,pr,db)
        return HttpResponse('<h1>分红成功</h1>\n<a href="../fh" target="_blank">继续分红</a>')

@csrf_exempt
def fhxj(request):
    if request.method=='POST':
        username=request.POST.get('username','')
        dm=request.POST.get('dm','')
        pg=request.POST.get('pg','')
        sql = 'select yue from jezh where username=:username'
        sql1='select cycount from grzq where username_gr=:username'
        pr = {
            'username': username
        }
        yue = select(sql, pr, db)
        cycount=select(sql1,pr,db)
        if yue and cycount:
            sql2='call pg(:username,:pg,:dm)'
            pr1={
                'username':username,
                'pg':pg,
                'dm':dm
            }
            inser(sql2,pr1,db)
            sql3='call upd(:username,:cmoney)'
            pr2={
                'username':username,
                'cmoney':yue[0][0]+(float(pg)*cycount[0][0])
            }
            inser(sql3,pr2,db)
            return HttpResponse('<h1>分红成功</h1>\n<a href="../fh" target="_blank">继续分红</a>')
        else:
            return HttpResponse('<h1>用户不存在，未开通资金账户或未持有该股</h1>')

def xx(request):
    context={}
    context['user']=usr[-1]
    sql='select * from jezh where username=:username'
    pr={
        'username':usr[-1].u_name
    }
    grxx=select(sql,pr,db)
    context['username']=grxx[0][0]
    context['yhkh'] = grxx[0][1]
    context['realname']=grxx[0][2]
    context['yue'] = grxx[0][3]
    return render(request,'xx.html',context)

def ckjl(request):
    context = {}
    c_list=[]
    context['user'] = usr[-1]
    ck_list=Cunkuan.objects.all()
    for ck in ck_list:
        if ck.username_ck==usr[-1].u_name:
            c_list.append(ck)
    context['c_list']=c_list
    return render(request, 'ckjl.html', context)

def hq(request):
    context = {}
    context['user'] = usr[-1]
    zq_list = Zqgl.objects.all()
    context['zq_list'] = zq_list
    return render(request, 'hq.html', context)

def mmr(request):
    dm=request.GET.get('dm')
    kc=request.GET.get('kc')
    zq_list=Zqgl.objects.all()
    sql='select dm from grzq where username_gr=:username'
    sql6='select yue from jezh where username=:username'
    pr={
        'username':usr[-1].u_name
    }
    u_dm=select(sql,pr,db)
    u_yue=select(sql6,pr,db)
    if u_dm[0][0]==dm:
        k=1
    else:
        k=0
    for zq in zq_list:
        if zq.dm==dm:
            mzq=zq
    sql1='insert into grzq values(:username,:pass,:dm,:zqname,:newprice,cycount)'
    sql2='insert into mr values(:username,:dm,:zqname,:dat)'
    sql3='call upm(:username,:dm)'
    sql4='call upc(:dm,:kc)'
    sql5='call upd(:username,:cmoney)'
    pr1={
        'username':usr[-1].u_name,
        'pass':'***',
        'dm':mzq.dm,
        'zqname':mzq.zqname,
        'newprice':mzq.newprice,
        'cycount':100
    }
    pr2={
        'username': usr[-1].u_name,
        'dm': mzq.dm,
        'zqname': mzq.zqname,
        'dat': time.asctime(time.localtime(time.time()))
    }
    pr3={
        'username': usr[-1].u_name,
        'dm': mzq.dm
    }
    pr4={
        'dm':mzq.dm,
        'kc':int(kc)-100
    }
    pr5={
        'username': usr[-1].u_name,
        'cmoney':u_yue[0][0]-(float(mzq.newprice)*100)
    }
    if k==0:
        inser(sql1,pr1,db)
        inser(sql4,pr4,db)
        inser(sql2,pr2,db)
        inser(sql5, pr5, db)
        return HttpResponse('<h1>买入成功</h1>\n<a href="../hq" target="_blank">继续买进</a>')
    else:
        inser(sql3,pr3,db)
        inser(sql4,pr4,db)
        inser(sql2,pr2,db)
        inser(sql5,pr5,db)
        return HttpResponse('<h1>买入成功</h1>\n<a href="../hq" target="_blank">继续买进</a>')


def cyzq(request):
    context = {}
    context['user'] = usr[-1]
    sql='select * from grzq where username_gr=:username'
    pr = {
        'username': usr[-1].u_name
    }
    gr_zq=select(sql,pr,db)
    if gr_zq:
        context['dm']=gr_zq[0][2]
        context['zqname'] = gr_zq[0][3]
        context['newprice']=gr_zq[0][4]
        context['cycount'] = gr_zq[0][5]
        return render(request,'cyzq.html',context)
    else:
        return HttpResponse('<h1>未持有证券</h1>')

def wt(request):
    dm = request.GET.get('dm')
    cycount = request.GET.get('cycount')
    sql='select cycount from grzq where username_gr=:username'
    pr={
        'username': usr[-1].u_name
    }
    gr_cct=select(sql,pr,db)
    if gr_cct[0][0]==0:
        k=0
    else:
        k=1
    zq_list=Zqgl.objects.all()
    for zq in zq_list:
        if zq.dm==dm:
            g_zq=zq
    if g_zq:
        sql1='call upc(:dm,:kc)'
        sql2='call del(:username,:dm)'
        sql3='call dom(:username,:dm)'
        pr1={
            'dm':dm,
            'kc':int(g_zq.kc)+100
        }
        pr2={
            'username':usr[-1].u_name,
            'dm':dm
        }
        if k==0:
            inser(sql2,pr2,db)
            return HttpResponse('<h1>委托股数量不足</h1>')
        else:
            inser(sql1,pr1,db)
            inser(sql3,pr2,db)
            return HttpResponse('<h1>委托成功</h1>\n<a href="../cyzq" target="_blank">继续委托</a>')
    else:
        return HttpResponse('<h1>所选股不存在或已过期</h1>')
def mr(request):
    context = {}
    context['user'] = usr[-1]
    sql='select * from mr where username=:username'
    pr = {
        'username': usr[-1].u_name
    }
    m_r=select(sql,pr,db)
    if m_r:
        context['mr_list']=m_r
        return render(request,'mr.html',context)
    else:
        return HttpResponse('<h1>没有买入记录</h1>\n<a href="../hq" target="_blank">去买进</a>')