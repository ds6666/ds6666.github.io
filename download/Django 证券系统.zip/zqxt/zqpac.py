import time
import threading
import matplotlib.pyplot as plt
import matplotlib
import cx_Oracle
import urllib.request
import urllib.parse
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import StaleElementReferenceException

chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--disable-gpu')
browser = webdriver.Chrome(options=chrome_options)
# //ul[@id="list-body"]/li/div[1]/a/
# //ul[@id="list-body"]/li/div/a[@class='linblock']/
# //ul[@id="list-body"]/li/div[3]/span/span/
# //ul[@id="list-body"]/li/div[6]/
#//ul[@id="list-body"]/li/div[7]/
# 10000
#//ul[@id="list-body"]/li/div[8]/
s=0
cj_list=[]
nprice_list=[]
lesten=0
middle=0
mortwenty=0
class Producer(threading.Thread):
    def __init__(self, threadname):
        threading.Thread.__init__(self, name = threadname)
    def run(self):
        pac()
        # print(self.getName(), ' put ', self.getName(), ' to queue.')

def find (xp):
    try:
        ret1 = browser.find_elements_by_xpath(xp)
        for one in ret1:
            if one.get_attribute('outerHTML') != '':
                break
            else:
                continue
    except StaleElementReferenceException:
        find(xp)
    return ret1
def get_one_page (url):
    browser = webdriver.Chrome()
    browser.get(url)
def inser(sql,pr,db):
    cr=db.cursor()
    cr.execute(sql,pr)
    cr.close()
    db.commit()

def pac():
    global s
    global lesten,middle,mortwenty
    ret = find('//ul[@id="list-body"]/li/div[1]/a')
    ret1 = find('//ul[@id="list-body"]/li/div/a[@class="linblock"]')
    ret2 = find('//ul[@id="list-body"]/li/div[3]/span/span')
    ret3 = find('//ul[@id="list-body"]/li/div[6]')
    ret4 = find('//ul[@id="list-body"]/li/div[7]')
    ret5 = 10000
    ret6 = find('//ul[@id="list-body"]/li/div[8]')
    for i in range(len(ret)):
        try:
            pr = {
                'dm': ret[i].text,
                'zqname': ret1[i].text,
                'newprice': ret2[i].text,
                'mrj': ret3[i].text,
                'mcj': ret4[i].text,
                'kc': ret5,
                'cjl': ret6[i].text
            }
            cj_list.append(int(pr['cjl']))
            nprice_list.append(float(pr['newprice']))
            if float(pr['newprice'])<10:
                lesten+=1
            elif float(pr['newprice'])>20:
                mortwenty+=1
            else:
                middle+=1
            # inser(sql,pr,db)
            print(pr)
            s+=1
        except StaleElementReferenceException:
            ret = find('//ul[@id="list-body"]/li/div[1]/a')
            ret1 = find('//ul[@id="list-body"]/li/div/a[@class="linblock"]')
            ret2 = find('//ul[@id="list-body"]/li/div[3]/span/span')
            ret3 = find('//ul[@id="list-body"]/li/div[6]')
            ret4 = find('//ul[@id="list-body"]/li/div[7]')
            ret5 = 10000
            ret6 = find('//ul[@id="list-body"]/li/div[8]')
            pr = {
                'dm': ret[i].text,
                'zqname': ret1[i].text,
                'newprice': ret2[i].text,
                'mrj': ret3[i].text,
                'mcj': ret4[i].text,
                'kc': ret5,
                'cjl': ret6[i].text
            }
            # inser(sql,pr,db)
            cj_list.append(int(pr['cjl']))
            nprice_list.append(float(pr['newprice']))
            if float(pr['newprice'])<10:
                lesten+=1
            elif float(pr['newprice'])>20:
                mortwenty+=1
            else:
                middle+=1
            print(pr)
            s+=1

if __name__ == '__main__':
    url='http://stockapp.finance.qq.com/mstats/?id=hk_wrnt#mod=list&id=ssa&module=SS&type=ranka&sort=2&page=1&max=40'
    db = cx_Oracle.connect('nanqu', 'tiger', 'localhost/south')
    sql='insert into zqgl values(:dm,:zqname,:newprice,:mrj,:mcj,:kc,:cjl)'
    m=browser.get(url)
    time.sleep(5)
    start_time=time.time()
    p=Producer('Prod')
    p.start()
    p.join()
    ls=time.time()-start_time
    with open('paclog.txt','a',encoding='utf-8') as f:
        f.write("开始时间：%s  历时：%.2f 秒  共爬取 %d 条数据" % (time.asctime(time.localtime(start_time)), ls, s)+'\n')
        f.close()
    # print("开始时间：%s  历时：%.2f 秒  共爬取 %d 条数据" % (time.asctime(time.localtime(start_time)), ls, s))
    browser.close()
    label_list = ["小于10", "10-20", "大于20"]  # 各部分标签
    size = [lesten, middle, mortwenty]  # 各部分大小
    color = ["red", "green", "blue"]  # 各部分颜色
    explode = [0.05, 0, 0]  # 各部分突出值
    matplotlib.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
    matplotlib.rcParams['axes.unicode_minus'] = False  # 正常显示负号
    # 第一行第一列图形
    ax1 = plt.subplot(2, 2, 1)
    # 第一行第二列图形
    ax2 = plt.subplot(2, 2, 2)
    # 第二行
    ax3 = plt.subplot(2, 1, 2)
    # 选择ax3
    plt.sca(ax3)
    plt.hist(cj_list, bins=40, facecolor="blue", edgecolor="black", alpha=0.7)
    # 显示横轴标签
    plt.xlabel("区间")
    # 显示纵轴标签
    plt.ylabel("频数/频率")
    # 显示图标题
    plt.title("证券成交量分布直方图")
    plt.sca(ax1)
    patches, l_text, p_text = plt.pie(size, explode=explode, colors=color, labels=label_list, labeldistance=1.1,
                                      autopct="%1.1f%%", shadow=False, startangle=90, pctdistance=0.6)
    plt.axis("equal")  # 设置横轴和纵轴大小相等，这样饼才是圆的
    plt.title("证券最新价格饼状图")
    plt.legend()
    plt.sca(ax2)
    plt.boxplot(nprice_list, labels=["NewPrice"])
    plt.title("证券最新价格箱线图")
    plt.show()
    # get_attribute('textContent')


