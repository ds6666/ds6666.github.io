"""zqxt URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from zqgl import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index/login',views.login),
    path('index/register',views.register),
    path('login_check/',views.login_check),
    path('zq_admin/',views.zq_admin),
    path('zq_user/',views.zq_user),
    path('register_check/',views.register_check),
    path('zqtj',views.zqtj),
    path('adzq/',views.adzq),
    path('zqhq',views.zqhq),
    path('ktzj',views.ktzj),
    path('adzj/',views.adzj),
    path('ck',views.ck),
    path('adck/',views.adck),
    path('fh',views.fh),
    path('szfh',views.szfh),
    path('xjfh',views.xjfh),
    path('fhxj/',views.fhxj),
    path('fhsz/',views.fhsz),
    path('xx',views.xx),
    path('ckjl',views.ckjl),
    path('hq',views.hq),
    path('mmr/',views.mmr),
    path('cyzq',views.cyzq),
    path('wt/',views.wt),
    path('mr',views.mr)
]
