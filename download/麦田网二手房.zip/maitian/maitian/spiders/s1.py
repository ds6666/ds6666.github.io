# -*- coding: utf-8 -*-
#//div[@class="list_title"]/h1/a/text()
#//div[@class="list_title"]/div/ol/strong/span/text()
# //div[@class="list_title"]/p/span[1]/text()
import scrapy
import re
import json
from maitian.items import MaitianItem

class S1Spider(scrapy.Spider):
    name = 's1'
    allowed_domains = ['maitian.cn']
    start_urls = ['http://bj.maitian.cn/esfall/PG0']
    for m in range(1, 15):
        n_url = 'http://bj.maitian.cn/esfall/PG' + str(m)
        start_urls.append(n_url)
    def parse(self, response):
        for item in response.xpath('//div[@class="list_title"]'):
            i=MaitianItem()
            i['title'] = item.xpath('./h1/a/text()').extract()[0]
            i['price'] = item.xpath('./div/ol/strong/span/text()').extract()[0]
            i['area']= item.xpath('./p/span[1]/text()').extract()[0]
            i['district']= item.xpath('./p/text()').re(r'昌平|朝阳|东城|大兴|房山|丰台|海淀|门头沟|平谷|石景山|顺义|通州|西城')[0]
            print(i)
            # with open('result.txt', 'a', encoding='utf-8') as f:
            #     f.write(json.dumps(i, ensure_ascii=False) + '\n')
            #     f.close()

