import time
import cx_Oracle
import urllib.request
import urllib.parse
from selenium import webdriver
from selenium.common.exceptions import StaleElementReferenceException

browser = webdriver.Chrome()
# //ul[@id="list-body"]/li/div[1]/a/
# //ul[@id="list-body"]/li/div/a[@class='linblock']/
# //ul[@id="list-body"]/li/div[3]/span/span/
# //ul[@id="list-body"]/li/div[6]/
#//ul[@id="list-body"]/li/div[7]/
# 10000
#//ul[@id="list-body"]/li/div[8]/
def find (xp):
    try:
        ret1 = browser.find_elements_by_xpath(xp)
        for one in ret1:
            if one.get_attribute('outerHTML') != '':
                break
            else:
                continue
    except StaleElementReferenceException:
        find(xp)
    return ret1
def get_one_page (url):
    browser = webdriver.Chrome()
    browser.get(url)
def inser(sql,pr,db):
    cr=db.cursor()
    cr.execute(sql,pr)
    cr.close()
    db.commit()
if __name__ == '__main__':
    url='http://stockapp.finance.qq.com/mstats/?id=hk_wrnt#mod=list&id=ssa&module=SS&type=ranka&sort=2&page=1&max=40'
    db = cx_Oracle.connect('nanqu', 'tiger', 'localhost/south')
    sql='insert into zqgl values(:dm,:zqname,:newprice,:mrj,:mcj,:kc,:cjl)'
    m=browser.get(url)
    time.sleep(5)
    ret=find('//ul[@id="list-body"]/li/div[1]/a')
    ret1=find('//ul[@id="list-body"]/li/div/a[@class="linblock"]')
    ret2=find('//ul[@id="list-body"]/li/div[3]/span/span')
    ret3 = find('//ul[@id="list-body"]/li/div[6]')
    ret4 = find('//ul[@id="list-body"]/li/div[7]')
    ret5 = 10000
    ret6 = find('//ul[@id="list-body"]/li/div[8]')
    for i in range(len(ret)):
        try:
            pr={
                'dm':ret[i].text,
                'zqname':ret1[i].text,
                'newprice':ret2[i].text,
                'mrj':ret3[i].text,
                'mcj':ret4[i].text,
                'kc':ret5,
                'cjl':ret6[i].text
            }
            inser(sql,pr,db)
        except StaleElementReferenceException:
            ret = find('//ul[@id="list-body"]/li/div[1]/a')
            ret1 = find('//ul[@id="list-body"]/li/div/a[@class="linblock"]')
            ret2 = find('//ul[@id="list-body"]/li/div[3]/span/span')
            ret3 = find('//ul[@id="list-body"]/li/div[6]')
            ret4 = find('//ul[@id="list-body"]/li/div[7]')
            ret5 = 10000
            ret6 = find('//ul[@id="list-body"]/li/div[8]')
            pr = {
                'dm': ret[i].text,
                'zqname': ret1[i].text,
                'newprice': ret2[i].text,
                'mrj': ret3[i].text,
                'mcj': ret4[i].text,
                'kc': ret5,
                'cjl': ret6[i].text
            }
            inser(sql,pr,db)
    # get_attribute('textContent')
    browser.close()

