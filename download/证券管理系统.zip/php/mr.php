<?php
	include 'cookie.php';  
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>买入记录</title>
	<link rel="stylesheet" type="text/css" href="zq1.css">
</head>
<body background="tp1.jpg" style="background-size:cover;">
	<span class="welcome">欢迎你：</span><span class="welcome"><?php  echo "$username"; ?></span>
	<center>
    <input type = "button" value = "个人信息" onclick="location.href='xx.php'" class="button"/>
    <input type = "button" value = "存款记录" onclick="location.href='ckjl.php'" class="button"/>
    <input type = "button" value = "证券行情" onclick="location.href='hq.php'" class="button"/>
    <input type = "button" value = "所持证券" onclick="location.href='cyzq.php'" class="button"/>
    <input type = "button" value = "买入记录" onclick="location.href='mr.php'" class="button"/>
    <input type = "button" value = "退出登录" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%">
    </center>
    <?php 
    include 'connect.php';
    ?> 
    <table width=600 border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#add3ef">
    <tr bgcolor="#eff3ff">
     <th>代码</th>
     <th>名称</th>
     <th>买入量</th>
     <th>买入时间</th>  
    </tr> 
    <?php 
    $orc="select * from mr where username='$username'";
    $state=oci_parse($conn, $orc);
    oci_execute($state);
    while ($row=oci_fetch_array($state, OCI_BOTH)){ 
    ?> 
    <tr bgColor="#ffffff">
     <td><?=$row[1]?></td>
     <td><?=$row[2]?></td>
     <td>100</td>
     <td><?=$row[3]?></td>
    </tr>
    <?php }?> 
</table>
</body>
</html>