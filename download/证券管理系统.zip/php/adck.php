<?php
	include 'cookie.php';
	$username = $_POST["username"];  
    $realname = $_POST["realname"];
    $ckmoney = $_POST["ckmoney"];
    include 'connect.php';
    $orc3 = "select yue from jezh where username='$username'";
    $st=oci_parse($conn, $orc3);
    oci_execute($st);
    $rw=oci_fetch_array($st, OCI_BOTH);
    $orc2 = "select to_char(sysdate,'yyyy-MM-dd HH24:mi:ss') from dual";
    $state=oci_parse($conn, $orc2);
    oci_execute($state);
    $row=oci_fetch_array($state, OCI_BOTH);
    $orc1 = "insert into cunkuan values('$username','$realname',$ckmoney,'$row[0]')";
    if($username!=null){
		if($realname!=null){
		    $stat=oci_parse($conn, $orc1);
		    $r=oci_execute($stat);
		    if($r){
		    	echo '存款成功';
		    }
		else {
    	echo "<script>alert('失败，返回存款界面');</script>";
        echo "<script> location.href='ck.php'  </script>";
			}
		}
	};
	if($username==null){
		    echo "<script>alert('请输入用户名！');location='ck.php';</script>";
		};
	if($realname==null){
	    echo "<script>alert('请输入姓名！');location='ck.php';</script>";
	};
	$orc2 = "call upd('$username',$rw[0]+$ckmoney)";
    $set=oci_parse($conn, $orc2);
    oci_execute($set);
    oci_free_statement($st);
    oci_free_statement($set);
	oci_free_statement($stat);
	oci_free_statement($state);
	oci_close($conn);
?>