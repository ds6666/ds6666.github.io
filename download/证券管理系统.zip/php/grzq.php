<?php
	include 'cookie.php';  
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>个人证券</title>
	<link rel="stylesheet" type="text/css" href="zq1.css">
</head>
<body background="tp1.jpg" style="background-size:cover;">
	<span class="welcome">欢迎你：</span><span class="welcome"><?php  echo "$username"; ?></span>
	<center>
    <input type = "button" value = "个人信息" onclick="location.href='xx.php'" class="button"/>
    <input type = "button" value = "存款记录" onclick="location.href='ckjl.php'" class="button"/>
    <input type = "button" value = "证券行情" onclick="location.href='hq.php'" class="button"/>
    <input type = "button" value = "所持证券" onclick="location.href='cyzq.php'" class="button"/>
    <input type = "button" value = "买入记录" onclick="location.href='mr.php'" class="button"/>
    <input type = "button" value = "退出登录" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%">
    <br><br><br><br><br><br> 
    <img src="t.png" height="55%">
    </center>
</body>
</html>