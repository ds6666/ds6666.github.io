<?php
	include 'cookie.php';  
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>证券行情</title>
	<link rel="stylesheet" type="text/css" href="zq1.css">
</head>
<body background="tp1.jpg" style="background-size:cover;">
	<span class="welcome">欢迎你：</span><span class="welcome"><?php  echo "$username"; ?></span>
	<center>
    <input type = "button" value = "个人信息" onclick="location.href='xx.php'" class="button"/>
    <input type = "button" value = "存款记录" onclick="location.href='ckjl.php'" class="button"/>
    <input type = "button" value = "证券行情" onclick="location.href='hq.php'" class="button"/>
    <input type = "button" value = "所持证券" onclick="location.href='cyzq.php'" class="button"/>
    <input type = "button" value = "买入记录" onclick="location.href='mr.php'" class="button"/>
    <input type = "button" value = "退出登录" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%">
    </center>
    <?php 
    include 'connect.php';
    ?>
    <table width=1000 border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#add3ef">
    <tr bgcolor="#ff3399">
     <th>代码</th>
     <th>名称</th>
     <th>最新价格</th>
     <th>买入价</th>
     <th>卖出价</th>
     <th>库存</th>
     <th>成交量</th>
     <th>买入/100股</th>  
    </tr> 
    <?php 
    $orc="select * from zqgl order by newprice";
    $state=oci_parse($conn, $orc);
    oci_execute($state);
    while ($row=oci_fetch_array($state, OCI_BOTH)){ 
    ?> 
    <tr bgColor="#ffffff">
     <td><?=$row[0]?></td>
     <td><?=$row[1]?></td>
     <td><?=$row[2]?></td>
     <td><?=$row[3]?></td>
     <td><?=$row[4]?></td> 
     <td><?=$row[5]?></td>
     <td><?=$row[6]?></td>
     <td><p align="center"><a href="mmr.php?dm=<?=$row[0]?>&kc=<?=$row[5]?>">买入</a></p></td> 
    </tr>
    <?php }?> 
</table>
</body>
</html>