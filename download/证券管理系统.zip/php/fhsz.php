<?php
	include 'cookie.php';
	$username = $_POST["username"];  
    $dm = $_POST["dm"];
    $sg = $_POST["zg"];
    $zg = $_POST["zg"];
    include 'connect.php';
    $orc1 = "call sz('$username','$dm',$sg+$zg)";
    if($username!=null){
		    $stat=oci_parse($conn, $orc1);
		    $r=oci_execute($stat);
		    if($r){
		    	echo '分红成功';
		    }
		else {
    	echo "<script>alert('失败，返回分红界面');</script>";
        echo "<script> location.href='szfh.php'  </script>";
			}
	};
	if($username==null){
		    echo "<script>alert('请输入用户名！');location='szfh.php';</script>";
		};
    oci_free_statement($sst);
	oci_free_statement($stat);
	oci_close($conn);
?>