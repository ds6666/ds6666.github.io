<?php
	include 'cookie.php';  
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>证券添加</title>
	<link rel="stylesheet" type="text/css" href="zq.css">
</head>
<body background="tp.jpg" style="background-size:cover;">
	<span class="welcome">欢迎你：</span><span class="welcome">证券管理员</span>
	<center>
    <input type = "button" value = "证券添加" onclick="location.href='zqtj.php'" class="button"/>
    <input type = "button" value = "开通资金账户" onclick="location.href='ktzj.php'" class="button"/>
    <input type = "button" value = "存款" onclick="location.href='ck.php'" class="button"/>
    <input type = "button" value = "证券行情" onclick="location.href='zqhq.php'" class="button"/>
    <input type = "button" value = "分红" onclick="location.href='fh.php'" class="button"/>
    <input type = "button" value = "清算" onclick="location.href='qs.php'" class="button"/>
    <input type = "button" value = "退出登录" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%"> 
    </center>
    <div class="k1">
    <form action = "adzq.php" method = "post">  
    <h1>添加证券
    <span>What's New Zq.</span>
    </h1>
    <label>
    <span>代码 :</span>
    <input type="text" name="dm" placeholder="Please input dm" />
    </label>
    <label>
    <span>名称 :</span>
    <input type="text" name="zqname" placeholder="Please input zqname" />
    </label>
    <label>
    <span>最新价格 :</span>
    <input type="text" name="newprice" placeholder="Please input newprice" />
    </label>
    <label>
    <span>买入价 :</span>
    <input type="text" name="mrj" placeholder="Please input mrprice" />
    </label>
    <label>
    <span>卖出价 :</span>
    <input type="text" name="mcj" placeholder="Please input mcprice" />
    </label>
    <label>
    <span>库存 :</span>
    <input type="text" name="kc" placeholder="Please input Kucun" />
    </label>
    <label>
    <span>成交量 :</span>
    <input type="text" name="cjl" placeholder="Please input chengjiao" />
    </label>
    <div style="margin-left:125px">
    <input type="submit" value="添加" class="submit">
    <input type = "reset" value = "重置" class="reset">
    </div>
    </form>
    </div>
</body>
</html>