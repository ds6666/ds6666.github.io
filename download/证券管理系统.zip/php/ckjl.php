<?php
	include 'cookie.php';  
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>存款记录</title>
	<link rel="stylesheet" type="text/css" href="zq1.css">
</head>
<body background="tp1.jpg" style="background-size:cover;">
	<span class="welcome">欢迎你：</span><span class="welcome"><?php  echo "$username"; ?></span>
	<center>
    <input type = "button" value = "个人信息" onclick="location.href='xx.php'" class="button"/>
    <input type = "button" value = "存款记录" onclick="location.href='ckjl.php'" class="button"/>
    <input type = "button" value = "证券行情" onclick="location.href='hq.php'" class="button"/>
    <input type = "button" value = "所持证券" onclick="location.href='cyzq.php'" class="button"/>
    <input type = "button" value = "买入记录" onclick="location.href='mr.php'" class="button"/>
    <input type = "button" value = "退出登录" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%">
    </center>
    <?php 
    include 'connect.php';
    ?> 
    <table width=800 border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#add3ef">
    <tr bgcolor="#ff3399">
     <th>用户名</th>
     <th>真实姓名</th>
     <th>存款金额</th>
     <th>存款日期</th>  
    </tr> 
    <?php 
    $orc="select * from cunkuan where username_ck='$username'";
    $state=oci_parse($conn, $orc);
    oci_execute($state);
    while ($row=oci_fetch_array($state, OCI_BOTH)){ 
    ?> 
    <tr bgColor="#ffffff">
     <td><?=$row[0]?></td>
     <td><?=$row[1]?></td>
     <td><?=$row[2]?></td>
     <td><?=$row[3]?></td>
    </tr>
    <?php }?> 
</table>
</body>
</html>