<?php
	include 'cookie.php';
    $dm = $_GET["dm"];
    $kc = $_GET["kc"];
    include 'connect.php';
    $orc5 = "select dm from grzq where username_gr='$username'";
    $s=oci_parse($conn, $orc5);
    oci_execute($s);
    $a=oci_fetch_array($s, OCI_BOTH);
    if ($a[0]==$dm) {
    	$k=1;
    }
    else{
    	$k=0;
    }
    $orc4 = "select yue from jezh where username='$username'";
    $t=oci_parse($conn, $orc4);
    oci_execute($t);
    $w=oci_fetch_array($t, OCI_BOTH);
    $orc3 = "select * from zqgl where dm='$dm'";
    $st=oci_parse($conn, $orc3);
    oci_execute($st);
    $rw=oci_fetch_array($st, OCI_BOTH);
    $orc2 = "select to_char(sysdate,'yyyy-MM-dd HH24:mi:ss') from dual";
    $state=oci_parse($conn, $orc2);
    oci_execute($state);
    $row=oci_fetch_array($state, OCI_BOTH);
    $orc1 = "insert into mr values('$username','$rw[0]','$rw[1]','$row[0]')";
    $orc6 = "insert into grzq values('$username','***','$rw[0]','$rw[1]',$rw[2],100)";
    $orc7 = "call upm('$username','$dm')";
    $orc8 = "call upc('$dm',$rw[5]-100)";
	$stat=oci_parse($conn, $orc1);
	$r=oci_execute($stat);
	if($r){
			if($k==0){
				$stt=oci_parse($conn, $orc6);
				oci_execute($stt);
				$sst=oci_parse($conn, $orc8);
				oci_execute($sst);
			    echo '买入成功';
			}
			else{
				$stt=oci_parse($conn, $orc7);
				oci_execute($stt);
				$sst=oci_parse($conn, $orc8);
				oci_execute($sst);
				echo '买入成功';
			}
		 }
	$orc2 = "call upd('$username',$w[0]-$rw[2]*100)";
    $set=oci_parse($conn, $orc2);
    oci_execute($set);
    oci_free_statement($s);
    oci_free_statement($t);
    oci_free_statement($st);
    oci_free_statement($sst);
    oci_free_statement($stt);
    oci_free_statement($set);
	oci_free_statement($stat);
	oci_free_statement($state);
	oci_close($conn);
?>