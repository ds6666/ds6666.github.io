<?php
//建立连接
$conn=oci_connect("nanqu","tiger","south","utf8");
//检查连接是否成功
if(!$conn){
    echo "连接数据库失败";
}
?>