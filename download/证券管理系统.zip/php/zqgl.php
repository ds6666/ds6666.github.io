<?php
	include 'cookie.php';  
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>证券管理</title>
	<link rel="stylesheet" type="text/css" href="zq.css">
</head>
<body background="tp.jpg" style="background-size:cover;">
	<span class="welcome">欢迎你：</span><span class="welcome">证券管理员</span>
	<center>
    <input type = "button" value = "证券添加" onclick="location.href='zqtj.php'" class="button"/>
    <input type = "button" value = "开通资金账户" onclick="location.href='ktzj.php'" class="button"/>
    <input type = "button" value = "存款" onclick="location.href='ck.php'" class="button"/>
    <input type = "button" value = "证券行情" onclick="location.href='zqhq.php'" class="button"/>
    <input type = "button" value = "分红" onclick="location.href='fh.php'" class="button"/>
    <input type = "button" value = "清算" onclick="location.href='qs.php'" class="button"/>
    <input type = "button" value = "退出登录" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%">
    <br><br><br><br><br><br> 
    <img src="t.png" height="55%">
    </center>
</body>
</html>