<?php
	include 'cookie.php';  
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>清算</title>
	<link rel="stylesheet" type="text/css" href="zq.css">
</head>
<body background="tp.jpg" style="background-size:cover;">
	<span class="welcome">欢迎你：</span><span class="welcome">证券管理员</span>
	<center>
    <input type = "button" value = "证券添加" onclick="location.href='zqtj.php'" class="button"/>
    <input type = "button" value = "开通资金账户" onclick="location.href='ktzj.php'" class="button"/>
    <input type = "button" value = "存款" onclick="location.href='ck.php'" class="button"/>
    <input type = "button" value = "证券行情" onclick="location.href='zqhq.php'" class="button"/>
    <input type = "button" value = "分红" onclick="location.href='fh.php'" class="button"/>
    <input type = "button" value = "清算" onclick="location.href='qs.php'" class="button"/>
    <input type = "button" value = "退出登录" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%"> 
    </center>
    <?php 
    include 'connect.php';
    ?> 
    <table width=600 border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#add3ef">
    <tr bgcolor="#eff3ff">
     <th>用户</th>
     <th>代码</th>
     <th>名称</th>
     <th>销售量</th>
     <th>销售时间</th>  
    </tr> 
    <?php 
    $orc="select * from mr order by mrdat";
    $state=oci_parse($conn, $orc);
    oci_execute($state);
    while ($row=oci_fetch_array($state, OCI_BOTH)){ 
    ?> 
    <tr bgColor="#ffffff">
     <td><?=$row[0]?></td>
     <td><?=$row[1]?></td>
     <td><?=$row[2]?></td>
     <td>100</td>
     <td><?=$row[3]?></td>
    </tr>
    <?php }?> 
</table>
</body>
</html>