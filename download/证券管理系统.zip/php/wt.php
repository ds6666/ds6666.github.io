<?php
    error_reporting(0);
	include 'cookie.php';
    $dm = $_GET["dm"];
    $cycount = $_GET["cycount"];
    include 'connect.php';
    $orc5 = "select cycount from grzq where username_gr='$username'";
    $s=oci_parse($conn, $orc5);
    oci_execute($s);
    $a=oci_fetch_array($s, OCI_BOTH);
    if ($a[0]==0) {
    	$k=0;
    }
    else{
    	$k=1;
    }
    $orc3 = "select * from zqgl where dm='$dm'";
    $st=oci_parse($conn, $orc3);
    oci_execute($st);
    $rw=oci_fetch_array($st, OCI_BOTH);
    $orc4 = "call upc('$dm',$rw[5]+100)";
    $orc6 = "call del('$username','$dm')";
    $orc7 = "call dom('$username','$dm')";
    if($k==0){
        $stt=oci_parse($conn, $orc6);
        oci_execute($stt);
        echo '委托股不存在';
    }
	else{
        $set=oci_parse($conn, $orc4);
        oci_execute($set);
		$stt=oci_parse($conn, $orc7);
		oci_execute($stt);
		echo '委托成功';
	}
    oci_free_statement($s);
    oci_free_statement($st);
    oci_free_statement($set);
    oci_free_statement($stt);
	oci_close($conn);
?>