<?php
	include 'cookie.php';
	$username = $_POST["username"];  
    $yhkh = $_POST["yhkh"];
    $realname = $_POST["realname"];
    include 'connect.php';
    $orc2 = "select u_name from userl where username='$username'";
    $sst=oci_parse($conn, $orc2);
    oci_execute($sst);
    $rs=oci_fetch_array($sst, OCI_BOTH);
    $orc1 = "insert into jezh values('$username','$yhkh','$realname',10.00)";
    if($username!=null){
    	if($rs[0]==$username){
		    $stat=oci_parse($conn, $orc1);
		    $r=oci_execute($stat);
		    if($r){
		    	echo '开通成功';
		    }
			else {
	    	echo "<script>alert('失败，返回开通界面');</script>";
	        echo "<script> location.href='ktzj.php'  </script>";
				}
		}
		else{
			echo "<script>alert('账户不存在！');location='zfktzj.php';</script>";
		}
	};
	if($username==null){
		    echo "<script>alert('请输入用户名！');location='ktzj.php';</script>";
		};
	oci_free_statement($sst);
	oci_free_statement($stat);
	oci_close($conn);
?>