<?php
	$username = $_POST['username'];
	$password = $_POST['password'];
	include 'connect.php';
	$orc="select * from userl where username='$username' and pass='$password'";
	$select=oci_parse($conn, $orc);
	oci_execute($select);
	$sum = oci_fetch_all($select, $res);
	if($sum>0)
	{
		if($username=='zqdba'&&$password=='tiger'){
		  		setcookie("username",$username,time()+3600);
		    	setcookie("password",$password,time()+3600);
		    	header("location:zqgl.php");
			}
		else{
				setcookie("username",$username,time()+3600);
		    	setcookie("password",$password,time()+3600);
		    	header("location:grzq.php");
		}
	}
?>