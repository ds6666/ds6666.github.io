<?php
	include 'cookie.php';
	$username = $_POST["username"];  
    $dm = $_POST["dm"];
    $pg = $_POST["pg"];
    include 'connect.php';
    $orc3 = "select yue from jezh where username='$username'";
    $st=oci_parse($conn, $orc3);
    oci_execute($st);
    $rw=oci_fetch_array($st, OCI_BOTH);
    $orc4 = "select cycount from grzq where username_gr='$username'";
    $sst=oci_parse($conn, $orc4);
    oci_execute($sst);
    $rs=oci_fetch_array($sst, OCI_BOTH);
    $orc1 = "call pg('$username',$pg,'$dm')";
    if($username!=null){
		    $stat=oci_parse($conn, $orc1);
		    $r=oci_execute($stat);
		    if($r){
		    	echo '分红成功';
		    }
		else {
    	echo "<script>alert('失败，返回分红界面');</script>";
        echo "<script> location.href='xjfh.php'  </script>";
			}
	};
	if($username==null){
		    echo "<script>alert('请输入用户名！');location='xjfh.php';</script>";
		};
	$orc2 = "call upd('$username',$rw[0]+($rs[0]*$pg))";
    $set=oci_parse($conn, $orc2);
    oci_execute($set);
    oci_free_statement($st);
    oci_free_statement($set);
    oci_free_statement($sst);
	oci_free_statement($stat);
	oci_close($conn);
?>