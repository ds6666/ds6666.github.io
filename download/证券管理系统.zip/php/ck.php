<?php
	include 'cookie.php';  
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>存款</title>
	<link rel="stylesheet" type="text/css" href="zq.css">
</head>
<body background="tp.jpg" style="background-size:cover;">
	<span class="welcome">欢迎你：</span><span class="welcome">证券管理员</span>
	<center>
    <input type = "button" value = "证券添加" onclick="location.href='zqtj.php'" class="button"/>
    <input type = "button" value = "开通资金账户" onclick="location.href='ktzj.php'" class="button"/>
    <input type = "button" value = "存款" onclick="location.href='ck.php'" class="button"/>
    <input type = "button" value = "证券行情" onclick="location.href='zqhq.php'" class="button"/>
    <input type = "button" value = "分红" onclick="location.href='fh.php'" class="button"/>
    <input type = "button" value = "清算" onclick="location.href='qs.php'" class="button"/>
    <input type = "button" value = "退出登录" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%"> 
    </center>
    <div class="k1">
    <form action = "adck.php" method = "post">  
    <h1>存款
    <span>Save Your Money.</span>
    </h1>
    <label>
    <span>用户名 :</span>
    <input type="text" name="username" placeholder="Your username" />
    </label>
    <label>
    <span>姓名 :</span>
    <input type="text" name="realname" placeholder="Please input realname" />
    </label>
    <label>
    <span>存储金额 :</span>
    <input type="text" name="ckmoney" placeholder="Please input ckmoney" />
    </label>
    <div style="margin-left:125px">
    <input type="submit" value="存款" class="submit">
    <input type = "reset" value = "重置" class="reset">
    </div>
    </div>
    </form>
</body>
</html>