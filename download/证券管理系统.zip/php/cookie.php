<?php 
if(!$_COOKIE["username"])
{
     header("location:login.html");
}
else
{
     include 'connect.php';
     $username=$_COOKIE["username"];
     $password=$_COOKIE["password"];
     $sql="select * from userl WHERE username='$username' AND pass='$password'";
     $select=oci_parse($conn,$sql);
     oci_execute($select);
     $sum=oci_fetch_all($select, $res);
     if($sum==0){
     echo "<script>alert('请前往登陆页面进行登陆');</script>";
     echo "<script> location.href='login.html'  </script>";
    }
     oci_free_statement($select);
     oci_close($conn);
}