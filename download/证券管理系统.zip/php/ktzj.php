<?php
	include 'cookie.php';  
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>资金账户开通</title>
	<link rel="stylesheet" type="text/css" href="zq.css">
</head>
<body background="tp.jpg" style="background-size:cover;">
	<span class="welcome">欢迎你：</span><span class="welcome">证券管理员</span>
	<center>
    <input type = "button" value = "证券添加" onclick="location.href='zqtj.php'" class="button"/>
    <input type = "button" value = "开通资金账户" onclick="location.href='ktzj.php'" class="button"/>
    <input type = "button" value = "存款" onclick="location.href='ck.php'" class="button"/>
    <input type = "button" value = "证券行情" onclick="location.href='zqhq.php'" class="button"/>
    <input type = "button" value = "分红" onclick="location.href='fh.php'" class="button"/>
    <input type = "button" value = "清算" onclick="location.href='qs.php'" class="button"/>
    <input type = "button" value = "退出登录" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%"> 
    </center>
    <div class="k1">
    <form action = "adzj.php" method = "post">  
    <h1>开通资金账户
    <span>What Can Use Money.</span>
    </h1>
    <label>
    <span>用户名 :</span>
    <input type="text" name="username" placeholder="Your username" />
    </label>
    <label>
    <span>银行卡号 :</span>
    <input type="text" name="yhkh" placeholder="Please input yhkh" />
    </label>
    <label>
    <span>真实姓名 :</span>
    <input type="text" name="realname" placeholder="Please input realname" />
    </label>
    <div style="margin-left:125px">
    <input type="submit" value="开通" class="submit">
    <input type = "reset" value = "重置" class="reset">
    </div>
    </div>
    </form>
</body>
</html>