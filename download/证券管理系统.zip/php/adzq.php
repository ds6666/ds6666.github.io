<?php
	include 'cookie.php';
	$dm = $_POST["dm"];  
    $zqname = $_POST["zqname"];
    $newprice = $_POST["newprice"];  
    $mrj = $_POST["mrj"];
    $mcj=$_POST["mcj"];
    $kc=$_POST["kc"];
    $cjl=$_POST["cjl"];
    include 'connect.php';
    $orc1 = "insert into zqgl values('$dm','$zqname',$newprice,$mrj,$mcj,$kc,$cjl)";
    if($dm!=null){
		if($zqname!=null){
		    $stat=oci_parse($conn, $orc1);
		    $r=oci_execute($stat);
		    if($r){
		    	echo '添加成功';
		    }
		else {
    	echo "<script>alert('失败，返回添加界面');</script>";
        echo "<script> location.href='zqtj.php'  </script>";
			}
		}
	};
	if($dm==null){
		    echo "<script>alert('请输入代码！');location='zqtj.php';</script>";
		};
	if($zqname==null){
	    echo "<script>alert('请输入名称！');location='zqtj.php';</script>";
	};
	oci_free_statement($stat);
	oci_close($conn);
?>