<?php
	$username = $_POST["username"];  
    $password = $_POST["password"];
    $repassword = $_POST["repassword"];
    $k=0;  
    include 'connect.php';
    $orc2 = "select username from userl";
    $state=oci_parse($conn, $orc2);
    oci_execute($state);
    while ($row=oci_fetch_array($state, OCI_BOTH))
    {
    	if($row[0]==$username){
    		$k=1;
    		echo "<script>alert('用户名已被占用');location='zhuce.html';</script>";
    	}
    }
    $orc1 = "insert into userl values(null,'$username','$password','$username')";
    if($username!=null){
		if($password!=null){
		    if($password==$repassword){
		    	if($k==0){
		    	$stat=oci_parse($conn, $orc1);
		    	$r=oci_execute($stat);
		    	echo '注册成功';
		    	}  	
		    }
			else {
	    	echo "<script>alert('两次密码不一致,返回上一页');</script>";
	        echo "<script> location.href='zhuce.html'</script>";
				}
		}
	};
	if($username==null){
		    echo "<script>alert('请输入用户名！');location='zhuce.html';</script>";
		};
	if($password==null){
	    echo "<script>alert('请输入密码！');location='zhuce.html';</script>";
	};
	oci_free_statement($stat);
	oci_free_statement($state);
	oci_close($conn);
?>