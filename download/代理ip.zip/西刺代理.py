import lxml
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup

xici_url='https://www.xicidaili.com/'

#构建请求头
headers={
    'User-Agent':''
}

#发送请求

req=urllib.request.Request(url=xici_url,headers=headers)
response=urllib.request.urlopen(req)
html=response.read().decode()
soup=BeautifulSoup(html,'lxml')
tr=soup.find('div',attrs={'class':'main'}).find_all('tr')[2:]
with open('proxy.txt','w',encoding='utf-8') as f:
    for ele in tr:
        try:
            ip=ele('td')[1].get_text()
            port=ele('td')[2].get_text()
            f.write(ip + ':' + port + '\n')
        except Exception as e:
            continue