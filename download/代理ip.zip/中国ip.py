import lxml
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup

cn_url='https://cn-proxy.com/'

#构建请求头
headers={
    'User-Agent':''
}

#发送请求

req=urllib.request.Request(url=cn_url,headers=headers)
response=urllib.request.urlopen(req)
html=response.read().decode()
soup=BeautifulSoup(html,'lxml')
tr=soup.find('div',attrs={'class':'table-container'}).find_all('tr')[2:]
with open('proxy1.txt','w',encoding='utf-8') as f:
    for ele in tr:
        try:
            ip=ele('td')[0].get_text()
            port=ele('td')[1].get_text()
            f.write(ip + ':' + port + '\n')
        except Exception as e:
            continue