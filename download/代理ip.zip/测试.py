import urllib.request
import random
url='http://httpbin.org/get'

proxy_support=urllib.request.ProxyHandler({'http':''})
#将多个ip存入iplist并随机选取ip代理格式如：'111.177.182.124:9999'
# iplist=['','','']
# proxy_support=urllib.request.ProxyHandler({'http':random.choice(iplist)})
opener=urllib.request.build_opener(proxy_support)

urllib.request.install_opener(opener)

headers={
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.90 Safari/537.36 2345Explorer/9.4.3.17934'
}
re=urllib.request.Request(url=url,headers=headers)
response=urllib.request.urlopen(re)

html=response.read().decode('utf-8')

print(html)