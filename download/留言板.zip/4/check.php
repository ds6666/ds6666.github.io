<?php
	include 'connect.php';
	$username = $_POST['username'];
	$password = $_POST['password'];
	$sql="select * from user WHERE username='$username' AND password='$password'";
	$select=mysqli_query($conn,$sql);
	$sum=mysqli_num_rows($select);
	  if($sum>0)
	  {
	    setcookie("username",$username,time()+3600);
	    setcookie("password",$password,time()+3600);
	    header("location:message.php");
	  } 
	  else
	  {
	  	 echo "<script>alert('用户名或密码错误');</script>";
	        echo "<script> location.href='login.html'  </script>";
	  }
	  mysqli_free_result($select);
	  mysqli_close($conn);
?>