<?php
    if(!$_COOKIE["username"])
    {
         header("location:login.html");
    }
    else
    {
         include 'connect.php';
         $username=$_COOKIE["username"];
         $password=$_COOKIE["password"];
         $sql="select * from user WHERE username='$username' AND password='$password'";
         $select=mysqli_query($conn,$sql);
         $sum=mysqli_num_rows($select);
         if($sum==0){
         echo "<script>alert('请前往登陆页面进行登陆');</script>";
         echo "<script> location.href='login.html'  </script>";
        }
    }
?>
<html>  
<head>  
<title>我的留言板.查看留言</title> 
<link rel="stylesheet" type="text/css" href="ly.css">
</head>  
<body background="tp.jpg" style="background-size:cover;">
<span class="welcome">欢迎你：</span><span class="welcome"><?php  echo "$username"; ?></span>
<center>
<input type = "button" value = "添加留言" onclick="location.href='message.php'" class="button"/>
<input type = "button" value = "查看留言" onclick="location.href='show.php'" class="button"/>
<input type = "button" value = "退出登陆" onclick="location.href='login.html'" class="button"/>
<hr width = "70%"> 
</center>
    <?php 
    include 'connect.php';
    error_reporting(0);
    ?> 
    <?php 
    echo "<p align='center'><a href='message.php'>继续添加</a></p>"; 
    ?> 
    <table width=500 border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#add3ef"> 
    <?php 
    $sql="select * from lyb order by time";
    $query=mysqli_query($conn,$sql);
    while ($row=mysqli_fetch_array($query)){ 
    ?> 
    <tr bgcolor="#eff3ff"> 
    <td>标题：<font color="red"><?=$row[title]?></font> 作者：<font color="red"><?=$row[author] ?></font><p align="right"><a href="delete.php?time=<?=$row[time]?>">删除</a></p></td> 
    </tr>
    <tr bgColor="#ffffff"> 
    <td>内容：<?=$row[liuyan]?></td> 
    </tr> 
    <tr bgColor="#ffffff"> 
    <td><p align="right">发表日期：<?=$row[time]?></p></td> 
    </tr> 
    <?php }?> 
</table>
</body>  
</html>