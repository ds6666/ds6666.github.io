<?php
	if (trim($_POST['password']) != trim($_POST['repassword'])) 
	{
	    exit('两次密码不一致,请返回上一页');
	}
	$username = trim($_POST['username']);
	$password = trim($_POST['password']);
	$time = time();
	$ip = $_SERVER['REMOTE_ADDR'];
	include 'connect.php';
	$sql = "insert into user (username,password,createtime,createip) values('$username','$password', '$time' ,'$ip' )";
	$result = mysqli_query($conn, $sql);
	if ($result) {
	    echo '注册成功';
	} 
	else {
	    echo "<script>alert('失败，请重新注册');</script>";
	        echo "<script> location.href='login.html'  </script>";
	}
	echo '当前用户插入的ID为' . mysqli_insert_id($conn);
	mysqli_close($conn);
?>