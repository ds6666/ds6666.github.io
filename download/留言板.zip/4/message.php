<?php 
if(!$_COOKIE["username"])
{
     header("location:login.html");
}
else
{
     include 'connect.php';
     $username=$_COOKIE["username"];
     $password=$_COOKIE["password"];
     $sql="select * from user WHERE username='$username' AND password='$password'";
     $select=mysqli_query($conn,$sql);
     $sum=mysqli_num_rows($select);
     if($sum==0){
     echo "<script>alert('请前往登陆页面进行登陆');</script>";
     echo "<script> location.href='login.html'  </script>";
    }
}
  mysqli_free_result($select);
  mysqli_close($conn);
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>留言板</title>
  <link rel="stylesheet" type="text/css" href="ly.css">
</head>
<body background="tp.jpg" style="background-size:cover;">
    <span class="welcome">欢迎你：</span><span class="welcome"><?php  echo "$username"; ?></span>
    <center>
    <input type = "button" value = "添加留言" onclick="location.href='message.php'" class="button"/>
    <input type = "button" value = "查看留言" onclick="location.href='show.php'" class="button"/>
    <input type = "button" value = "退出登陆" onclick="location.href='login.html'" class="button"/>
    <hr width = "70%"> 
    </center>
    <div class="k1">
    <form action = "doAdd.php" method = "post">  
    <h1>留言板
    <span>What's New To Share With You。</span>
    </h1>
    <label>
    <span>Your Name :</span>
    <input type="text" name="author" placeholder="Your Full Name" />
    </label>
    <label>
    <span>Title :</span>
    <input type="text" name="title" placeholder="Please input title" />
    </label>
    <label>
    <span>Message :</span>
    <textarea name="content" placeholder="Your Message to Us"></textarea>
    </label>
    <div style="margin-left:125px">
    <input type="submit" value="提交" class="submit">
    <input type = "reset" value = "重置" class="reset">
    </div>
    </div>
    </form>
</body>