<?php
$conn = mysqli_connect('localhost', 'root', '');      
if (mysqli_errno($conn)) {
    echo '数据库连接错误！';
    exit;
}
mysqli_select_db($conn, 'yh');   //选择数据库
mysqli_set_charset($conn, 'utf8');   //选择字符集
?>