<?php
	if(!$_COOKIE["username"])
	{
	     header("location:login.html");
	}
	else
	{
	     include 'connect.php';
	     $username=$_COOKIE["username"];
	     $password=$_COOKIE["password"];
	     $sql="select * from user WHERE username='$username' AND password='$password'";
	     $select=mysqli_query($conn,$sql);
	     $sum=mysqli_num_rows($select);
	     if($sum==0){
	     echo "<script>alert('请前往登陆页面进行登陆');</script>";
	     echo "<script> location.href='login.html'  </script>";
	    }
	}
    $title = $_POST["title"];  
    $author = $_POST["author"];
    $content = $_POST["content"];  
    $ip = $_SERVER["REMOTE_ADDR"];
    include 'connect.php';
    $sql1 = "insert into lyb (user,title,author,ip,liuyan,time) values('$username','$title','$author','$ip','$content',now())";
    if($title!=null){
		if($author!=null){
		    $result = mysqli_query($conn, $sql1);
		    if($result){
		    	echo '留言成功';
		    }
		    else {
    	echo "<script>alert('失败，请重新留言');</script>";
        echo "<script> location.href='message.php'  </script>";
			}
		}
	};
	if($author==null){
		    echo "<script>alert('请输入留言者！');location='message.php';</script>";
		};
	if($title==null){
	    echo "<script>alert('请输入留言标题！');location='message.php';</script>";
	};
  	mysqli_close($conn);
?>