<?php 
	include 'connect.php'; 
	$time = $_GET['time']; 
	$query="delete from lyb where time='$time'"; 
	mysqli_query($conn,$query); 
	?> 
	<?php  
	echo "<script language='javascript' type='text/javascript'>"; 
	echo "location.href='show.php'"; 
	echo "</script>"; 
?>